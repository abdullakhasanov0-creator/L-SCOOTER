package com.limonchik.escooter

/**
 * Точка расширения для прошивки. В KCQ Scooter 1.5.4 нет ни одной команды прошивки (OTA/DFU):
 * проверено по строкам и классам classes.dex. Пока формат пакетов неизвестен, прошивать нечем.
 */
interface FirmwareFlasher {
    val available: Boolean
    val reason: String
}

object NoFlasher : FirmwareFlasher {
    override val available: Boolean = Config.FIRMWARE_PROTOCOL_KNOWN
    override val reason: String =
        "В оригинальном приложении KCQ Scooter 1.5.4 нет команд прошивки. Формат пакетов обновления неизвестен, " +
            "поэтому запись прошивки в контроллер отключена. Выдуманные байты могут вывести контроллер из строя."
}
